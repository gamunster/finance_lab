
import { Grid } from './Grid';
import { SolverParams, CalculationResult, DoubleFunction } from '../types';

export class ChernoffSolver {
  /**
   * Solve the Black-Scholes PDE using Chernoff Approximations.
   * L = a(x)f''(x) + b(x)f'(x) + c(x)f(x)
   */
  public static solve(params: SolverParams): CalculationResult {
    const startTime = performance.now();
    
    // 1. Map Black-Scholes to Operator Coefficients
    // a(x) = 0.5 * sigma^2 * x^2
    const a: DoubleFunction = (x) => 0.5 * Math.pow(params.volatilityFn(x), 2) * Math.pow(x, 2);
    // b(x) = r * x
    const b: DoubleFunction = (x) => params.interestRateFn(x) * x;
    // c(x) = -r
    const c: DoubleFunction = (x) => -params.interestRateFn(x);

    // 2. Setup Grid
    // Range should cover far enough for the shifts
    const xMin = 0;
    const xMax = params.s0 * 3.5; // Heuristic boundary
    const gridSize = 800;
    let grid = new Grid(xMin, xMax, gridSize);

    // 3. Set Initial Payoff
    const payoff: DoubleFunction = (x) => {
      if (params.optionType === 'call') {
        return Math.max(0, x - params.strike);
      } else {
        return Math.max(0, params.strike - x);
      }
    };

    for (let i = 0; i < gridSize; i++) {
      grid.setValue(i, payoff(grid.getX(i)));
    }

    // 4. Iterate Chernoff Function S(t/n)^n
    const dt = params.time / params.iterations;
    
    for (let step = 0; step < params.iterations; step++) {
      const nextGrid = new Grid(xMin, xMax, gridSize);
      
      for (let i = 0; i < gridSize; i++) {
        const x = grid.getX(i);
        
        const ax = a(x);
        const bx = b(x);
        const cx = c(x);

        // Theorem 6 Translation-Based Formula
        // (S(dt)f)(x) = 1/4 f(x + 2*sqrt(ax*dt)) + 1/4 f(x - 2*sqrt(ax*dt)) + 1/2 f(x + 2*bx*dt) + dt*cx*f(x)
        
        const sqrtTerm = 2 * Math.sqrt(Math.max(0, ax * dt));
        const val1 = grid.getValueAt(x + sqrtTerm);
        const val2 = grid.getValueAt(x - sqrtTerm);
        const val3 = grid.getValueAt(x + 2 * bx * dt);
        const val4 = grid.getValueAt(x);

        const nextVal = (0.25 * val1) + (0.25 * val2) + (0.5 * val3) + (dt * cx * val4);
        nextGrid.setValue(i, nextVal);
      }
      grid = nextGrid;
    }

    const finalPrice = grid.getValueAt(params.s0);
    const executionTimeMs = performance.now() - startTime;

    // Numerical error estimation heuristic based on n and t
    const errorEstimate = (params.time * params.time) / params.iterations;

    const gridX: number[] = [];
    const gridY: number[] = [];
    for (let i = 0; i < gridSize; i += 10) {
      gridX.push(grid.getX(i));
      gridY.push(grid.getValueAt(grid.getX(i)));
    }

    return {
      price: finalPrice,
      gridX,
      gridY,
      errorEstimate,
      executionTimeMs
    };
  }
}
