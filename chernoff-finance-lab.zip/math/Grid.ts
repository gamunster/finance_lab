
export class Grid {
  private values: Float64Array;
  private xMin: number;
  private xMax: number;
  private size: number;
  private step: number;

  constructor(xMin: number, xMax: number, size: number) {
    this.xMin = xMin;
    this.xMax = xMax;
    this.size = size;
    this.step = (xMax - xMin) / (size - 1);
    this.values = new Float64Array(size);
  }

  public setValue(index: number, val: number): void {
    this.values[index] = val;
  }

  public getValueAt(x: number): number {
    if (x <= this.xMin) return this.values[0];
    if (x >= this.xMax) return this.values[this.size - 1];

    const idx = (x - this.xMin) / this.step;
    const i = Math.floor(idx);
    const frac = idx - i;

    // Linear interpolation
    return this.values[i] * (1 - frac) + this.values[i + 1] * frac;
  }

  public getX(index: number): number {
    return this.xMin + index * this.step;
  }

  public getSize(): number {
    return this.size;
  }

  public copy(): Grid {
    const g = new Grid(this.xMin, this.xMax, this.size);
    g.values.set(this.values);
    return g;
  }
}
