
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import ParameterInput from './components/ParameterInput';
import PriceChart from './components/PriceChart';
import ResultsPanel from './components/ResultsPanel';
import { ChernoffSolver } from './math/ChernoffSolver';
import { SolverParams, CalculationResult } from './types';

const App: React.FC = () => {
  const [params, setParams] = useState<SolverParams>({
    s0: 100,
    strike: 100,
    time: 1.0,
    volatilityFn: (x) => 0.2,
    interestRateFn: (x) => 0.05,
    iterations: 1000,
    optionType: 'call'
  });

  const [result, setResult] = useState<CalculationResult | null>(null);
  const [loading, setLoading] = useState(false);

  const calculate = useCallback(() => {
    setLoading(true);
    // Use setTimeout to allow UI to show loader
    setTimeout(() => {
      try {
        const res = ChernoffSolver.solve(params);
        setResult(res);
      } catch (err) {
        console.error("Calculation error", err);
      } finally {
        setLoading(false);
      }
    }, 50);
  }, [params]);

  // Initial calculation
  useEffect(() => {
    calculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Intro Section */}
          <div className="lg:col-span-12 mb-2">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-3xl font-bold text-white mb-1">Advanced Financial Computing</h2>
                <p className="text-slate-400">Numerical solver for Black-Scholes using iterated shift operators.</p>
              </div>
              <div className="flex gap-3">
                <div className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-lg text-xs font-mono">
                  <span className="text-indigo-400">ENGINE:</span> v2.5-remizov
                </div>
                <div className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-lg text-xs font-mono">
                  <span className="text-emerald-400">PRECISION:</span> 64-bit PCM
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Parameters */}
          <div className="lg:col-span-4 xl:col-span-3">
            <ParameterInput 
              params={params} 
              setParams={setParams} 
              onCalculate={calculate}
              isLoading={loading}
            />
          </div>

          {/* Main Visualizations */}
          <div className="lg:col-span-8 xl:col-span-6 space-y-6">
            <div className="h-[450px]">
              <PriceChart gridX={result?.gridX || []} gridY={result?.gridY || []} strike={params.strike} />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
               <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
                 <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Model Equations</h4>
                 <div className="space-y-3 font-mono text-sm">
                   <div className="bg-slate-950 p-2 rounded border border-slate-800/50">
                     <span className="text-indigo-400">L = a(x)f'' + b(x)f' + c(x)f</span>
                   </div>
                   <div className="bg-slate-950 p-2 rounded border border-slate-800/50 text-[10px]">
                     <span className="text-slate-400">a(x) = 0.5 σ² x²</span><br/>
                     <span className="text-slate-400">b(x) = r x</span><br/>
                     <span className="text-slate-400">c(x) = -r</span>
                   </div>
                 </div>
               </div>

               <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
                 <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Grid Convergence</h4>
                 <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                   The solution converges at rate O(1/n) based on the Translation-Based approximation of the C₀-semigroup.
                 </p>
                 <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500" style={{ width: '85%' }}></div>
                 </div>
                 <div className="flex justify-between mt-1">
                   <span className="text-[10px] text-slate-600">Iterative refinement</span>
                   <span className="text-[10px] text-indigo-400 font-bold">STABLE</span>
                 </div>
               </div>
            </div>
          </div>

          {/* Right Sidebar - Stats */}
          <div className="lg:col-span-12 xl:col-span-3">
            <ResultsPanel result={result} />
          </div>

        </div>
      </main>

      <footer className="mt-12 py-8 border-t border-slate-900 bg-slate-950 text-center">
        <p className="text-slate-600 text-xs uppercase tracking-widest font-medium">
          Powered by React 18 & Gemini AI Engineering • © 2025 Chernoff Finance Lab
        </p>
      </footer>
    </div>
  );
};

export default App;
