
export type DoubleFunction = (x: number) => number;

export interface SolverParams {
  s0: number;
  strike: number;
  time: number;
  volatilityFn: DoubleFunction;
  interestRateFn: DoubleFunction;
  iterations: number;
  optionType: 'call' | 'put';
}

export interface CalculationResult {
  price: number;
  gridX: number[];
  gridY: number[];
  errorEstimate: number;
  executionTimeMs: number;
}
