
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface PriceChartProps {
  gridX: number[];
  gridY: number[];
  strike: number;
}

const PriceChart: React.FC<PriceChartProps> = ({ gridX, gridY, strike }) => {
  const data = gridX.map((x, i) => ({
    x: parseFloat(x.toFixed(2)),
    y: parseFloat(gridY[i].toFixed(2))
  }));

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 h-full shadow-2xl overflow-hidden flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2 text-indigo-400">
          <i className="fa-solid fa-chart-line"></i>
          <h2 className="font-semibold text-lg text-white">Option Price Distribution</h2>
        </div>
        <div className="text-[10px] text-slate-500 font-mono flex gap-4">
          <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-indigo-500"></div> Value</span>
          <span className="flex items-center gap-1"><div className="w-2 h-0.5 bg-red-400"></div> Strike</span>
        </div>
      </div>
      
      <div className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorY" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis 
              dataKey="x" 
              stroke="#64748b" 
              fontSize={12} 
              tickLine={false} 
              axisLine={false}
              label={{ value: 'Asset Price ($)', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12} 
              tickLine={false} 
              axisLine={false}
              label={{ value: 'Option Value', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
              itemStyle={{ color: '#f8fafc' }}
              labelStyle={{ color: '#6366f1' }}
            />
            <ReferenceLine x={strike} stroke="#ef4444" strokeDasharray="3 3" label={{ value: 'K', fill: '#ef4444', fontSize: 10, position: 'top' }} />
            <Area 
              type="monotone" 
              dataKey="y" 
              stroke="#6366f1" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorY)" 
              animationDuration={1500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PriceChart;
