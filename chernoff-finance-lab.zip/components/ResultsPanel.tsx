
import React from 'react';
import { CalculationResult } from '../types';

interface ResultsPanelProps {
  result: CalculationResult | null;
}

const ResultsPanel: React.FC<ResultsPanelProps> = ({ result }) => {
  if (!result) return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 h-full flex items-center justify-center text-slate-500">
      <div className="text-center">
        <i className="fa-solid fa-hourglass-start text-4xl mb-4 block opacity-20"></i>
        <p>Awaiting calculation results...</p>
      </div>
    </div>
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 h-full shadow-2xl flex flex-col">
      <div className="flex items-center gap-2 mb-6 text-emerald-400">
        <i className="fa-solid fa-square-poll-vertical"></i>
        <h2 className="font-semibold text-lg text-white">Analysis Results</h2>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Option Price</p>
          <p className="text-3xl font-bold text-emerald-400 mono">
            ${result.price.toFixed(4)}
          </p>
        </div>
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Numerical Error</p>
          <p className="text-3xl font-bold text-amber-400 mono">
            ±{result.errorEstimate.toFixed(6)}
          </p>
        </div>
      </div>

      <div className="space-y-4 flex-1">
        <div className="border-t border-slate-800 pt-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase mb-3">Engine Statistics</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Algorithm</span>
              <span className="text-slate-300">Chernoff-Remizov (T6)</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Computation Time</span>
              <span className="text-slate-300">{result.executionTimeMs.toFixed(2)} ms</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Operator Semigroup</span>
              <span className="text-slate-300 italic text-xs">C₀-strongly continuous</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/30 p-4 rounded-lg border border-slate-800/50">
          <p className="text-[10px] text-slate-400 leading-relaxed italic">
            "The Chernoff approximation method allows us to express exp(tL) in terms of variable coefficients a(x), b(x), and c(x), representing the solution to the nonhomogeneous linear ODE."
            <span className="block mt-1 font-bold">— I.D. Remizov (2025)</span>
          </p>
        </div>
      </div>

      <button className="w-full border border-indigo-600 text-indigo-400 hover:bg-indigo-600/10 py-3 rounded-lg mt-6 font-semibold transition-all">
        <i className="fa-solid fa-file-export mr-2"></i> Export Report
      </button>
    </div>
  );
};

export default ResultsPanel;
