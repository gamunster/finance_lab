
import React from 'react';
import { SolverParams } from '../types';

interface ParameterInputProps {
  params: SolverParams;
  setParams: (p: SolverParams) => void;
  onCalculate: () => void;
  isLoading: boolean;
}

const ParameterInput: React.FC<ParameterInputProps> = ({ params, setParams, onCalculate, isLoading }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'volatility' || name === 'interestRate') {
      // Create a function from the input
      const numericVal = parseFloat(value);
      const fn = (x: number) => numericVal; // Simple constant for now, could be parsed
      setParams({
        ...params,
        [name === 'volatility' ? 'volatilityFn' : 'interestRateFn']: fn,
        [name + 'Value']: value // Store literal for UI
      } as any);
    } else {
      setParams({
        ...params,
        [name]: name === 'optionType' ? value : parseFloat(value)
      });
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 h-full shadow-2xl">
      <div className="flex items-center gap-2 mb-6 text-indigo-400">
        <i className="fa-solid fa-sliders"></i>
        <h2 className="font-semibold text-lg text-white">Model Parameters</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Asset Price (S₀)</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
            <input 
              name="s0"
              type="number" 
              value={params.s0}
              onChange={handleChange}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 pl-8 pr-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Strike Price (K)</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
            <input 
              name="strike"
              type="number" 
              value={params.strike}
              onChange={handleChange}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 pl-8 pr-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Maturity (T)</label>
            <input 
              name="time"
              type="number" 
              step="0.1"
              value={params.time}
              onChange={handleChange}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Iterations (n)</label>
            <input 
              name="iterations"
              type="number" 
              value={params.iterations}
              onChange={handleChange}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Volatility (σ)</label>
          <input 
            name="volatility"
            type="number" 
            step="0.01"
            onChange={handleChange}
            placeholder="e.g., 0.2"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
          <p className="text-[10px] text-slate-500 mt-1 italic">* Constant implementation (maps to σ(x) = const)</p>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Interest Rate (r)</label>
          <input 
            name="interestRate"
            type="number" 
            step="0.01"
            onChange={handleChange}
            placeholder="e.g., 0.05"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Option Type</label>
          <select 
            name="optionType"
            value={params.optionType}
            onChange={handleChange}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all appearance-none cursor-pointer"
          >
            <option value="call">European Call</option>
            <option value="put">European Put</option>
          </select>
        </div>

        <button 
          onClick={onCalculate}
          disabled={isLoading}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-3 rounded-lg mt-4 transition-all shadow-lg shadow-indigo-600/20 active:scale-95 flex items-center justify-center"
        >
          {isLoading ? (
            <i className="fa-solid fa-spinner fa-spin mr-2"></i>
          ) : (
            <i className="fa-solid fa-bolt mr-2"></i>
          )}
          RUN SOLVER
        </button>
      </div>
    </div>
  );
};

export default ParameterInput;
